import java.io.*;
import java.net.*;
import org.json.*;
import java.util.*;

public class CS1003Bored {
    public static void main(String args[]) {
        try {
            String mode = args[1];
            //default URL for getting a random activity
            URL boredPath = new URL("http://www.boredapi.com/api/activity");
            File cacheDirectory = new File(args[0]);
            //checks if user input CACHEDIR is a directory
            if (cacheDirectory.isDirectory()) {
                //switch case changes behavior of program depending on what user sets MODE to
                switch (mode) {
                    case ("random"): {
                        //check for correct number of arguments
                        if (args.length != 2) {
                            System.out.println("Expected two arguments when MODE is set to random");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 

                        else
                            printFromURL(boredPath, mode);
                        break;
                    }
                    case ("type"): {
                        //check for correct number of arguments
                        if (args.length < 3) {
                            System.out.println("Expected a third argument when MODE is set to type");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        else if (args.length > 3) {
                            System.out.println("Expected three arguments when MODE is set to type");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 

                        else {
                            String value = args[2];

                            //check if user input VALUE is expected 
                            String exceptedValues[] = new String[] { "busywork", "charity", "cooking", "diy","education", "music", "recreational", "relaxation", "social" };
                            boolean goodValue = false;
                            for (String s : exceptedValues) {
                                if (value.equals(s)) {
                                    goodValue = true;
                                }
                            }

                            if (goodValue) {
                                //changes URL to look for activities with specific type
                                boredPath = new URL("http://www.boredapi.com/api/activity?type=" + value);
                                printFromURL(boredPath, mode);
                            } 
                            else {
                                System.out.println("Unexpected value for type: " + value);
                                System.out.println("Expected one of: busywork, charity, cooking, diy, education, music, recreational, relaxation, social");
                                System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                            }
                        }
                        break;
                    }
                    case ("participants"): {
                        //check for correct number of arguments
                        if (args.length < 3) {
                            System.out.println("Expected a third argument when MODE is set to participants");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        else if (args.length > 3) {
                            System.out.println("Expected three arguments when MODE is set to participants");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        
                        else {
                            //check if user input VALUE is expected
                            if ((Integer.parseInt(args[2]) > 5 || Integer.parseInt(args[2])< 1) && Integer.parseInt(args[2])!=8) {
                                System.out.println("No activities found with " + args[2]+" participants");
                                System.out.println("Expected 1-5 or 8 participants");
                                System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                            }

                            else {
                                String value = args[2];
                                //changes URL to look for activities by number of participants
                                boredPath = new URL("http://www.boredapi.com/api/activity?participants=" + value);
                                printFromURL(boredPath, mode);
                            }
                        }
                        break;
                    }
                    case ("key"): {
                        //check for correct number of arguments
                        if (args.length < 3) {
                            System.out.println("Expected a third argument when MODE is set to key");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        else if (args.length > 3) {
                            System.out.println("Expected three arguments when MODE is set to key");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        
                        else {
                            printFromCache(args[0], args[2]);
                        }
                        break;
                    }
                    case ("summary"): {
                        //check for correct number of arguments
                        if (args.length != 2) {
                            System.out.println("Expected two arguments when MODE is set to summary");
                            System.out.println("But got " + args.length + " arguments");
                            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                        } 
                        
                        else {
                            summary(cacheDirectory);
                        }
                        break;
                    }
                    default: {
                        System.out.println("Unexpected value for MODE: " + args[1]);
                        System.out.println("Expected one of: random, type, participants, key, summary");
                        System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
                    }
                }
            } 
            else {
                System.out.println("Cache directory does not exist: no_such_cachedir");
                System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
            }

        } 
        //catches exception when user enter less than two arguments
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Expected two or three arguments, but got: " + args.length);
            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
        }

        catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }

        //catches exception when user does not enter an integer for VALUE when MODE is set to participants
        catch(NumberFormatException e) {
            System.out.println("NumberFormatException: Expected VALUE to be an integer when MODE is set to participants");
            System.out.println("Usage: java CS1003Bored CACHEDIR MODE [VALUE]");
        }
    }
    
    /**
     * Handles getting and printing activities from a URL when MODE is set to random, type or participants
     * @param path URL to boredapi to get an activity
     * @param mode The mode set by the user 
     */
    public static void printFromURL(URL path, String mode) {
        try {
            //get/read content from URL
            URLConnection connection = path.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            //create JSONObject from URL content
            String line = "";
            while ((line = reader.readLine()) != null) {
                JSONObject activity = new JSONObject(line);

                //prints slightly different output when MODE is set to random
                if (mode.equals("random"))
                    System.out.println("Found a " + activity.getString("type") + " activity.");
                else
                    System.out.println("Found an activity of type " + activity.getString("type"));
                    System.out.println("Number of participants needed: " + activity.getInt("participants"));
                    System.out.println("Description: " + activity.getString("activity"));
            }
            reader.close();
        } 
        catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }

    /**
     * Handles getting and printing activities from a stored cache when MODE is set to key
     * @param cachePath path to cache directory containing the activities
     * @param key key of the activity user is attempting to get
     */
    public static void printFromCache(String cachePath, String key) {
        try {
            //create path to JSON file of activity searched for
            File f = new File(cachePath + "/" + key + ".json");

            //create JSONObject from content in JSON cache file
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = "";
            String jsonText = "";
            while ((line = reader.readLine()) != null) {
                jsonText = jsonText + line;
            }
            JSONObject activity = new JSONObject(jsonText);

            System.out.println("Found an activity of type " + activity.getString("type"));
            System.out.println("Number of participants needed: " + activity.getInt("participants"));
            System.out.println("Description: " + activity.getString("activity"));

            reader.close();
        } 
        catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }

    /**
     * prints the top 10 most used words in the activity field of the JSON files in cache
     * @param dir the cache directory containing the JSON files
     */
    public static void summary(File dir) {
        try {
            //initialise map of unique words and frequencies used
            Map<String, Integer> wordCounter = new TreeMap<>();
                //iterate through all files in cache
                for (File file : dir.listFiles()) {
                    //create JSONObject from JSON files in cache
                    BufferedReader reader = new BufferedReader(new FileReader(file));
                    String line = "";
                    String text = "";
                    while ((line = reader.readLine()) != null) {
                        text = text + line;
                    }
                    JSONObject activity = new JSONObject(text);

                    //populate map of unique words
                    String[] description = activity.getString("activity").replaceAll("[^a-zA-Z0-9]", " ").split(" ");
                    for (String word : description) {
                        String s = word.toLowerCase();
                        if (wordCounter.containsKey(s)) {
                            wordCounter.put(s, wordCounter.get(s) + 1);
                        } else {
                            wordCounter.put(s, 1);
                        }
                    }
                    reader.close();
                }

                //create map with entries sorted by value
                Map<String, Integer> sortedMap = new LinkedHashMap<>();
                wordCounter.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).forEachOrdered(word -> sortedMap.put(word.getKey(), word.getValue()));
                
                //print top 10 most frequently used words
                System.out.println("Most frequent words in the activity fields:");
                int counter = 1;
                for (String word : sortedMap.keySet()) {
                    System.out.println("\t" + sortedMap.get(word) + "\t" + word);
                    counter++;
                    if (counter > 10) break;
                }
        } 
        catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }
}