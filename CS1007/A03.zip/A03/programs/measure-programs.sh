#!/bin/bash
#checks if user entered in 1 argument and throws error and exits if they did not
if [ $# -ne 1 ]; then
    echo "error: usage $0 <directory>"
    exit 1
fi

#throws error if the user entered directory does not exist
if [ ! -d $1 ]; then
    echo "error: directroy does not exist"
    exit 1
fi

#deletes shared volume used by script if it already exists
podman volume rm --force $1-volume
cd $1
#formats csv file which logs data on the programs
echo "ID, CPU Usage, CPU Usage %, Memory Usage, Memory Usage %" > $1-usage.csv
#creates shared volume to check if input file was correctly modified
podman volume create $1-volume
#builds container
podman build -t container .

N=0
#runs container 10 times and records podman stats data into usage.csv
while [ $N -lt 10 ]; do
    podman stats -l -i=1 --format "{{.ID}}, {{.CPU}}, {{.CPUPerc}}, {{.MemUsage}}, {{.MemPerc}}" >> $1-usage.csv &
    podman run -v $1-volume:/volume container
    kill $!   #stops podman stats from running forever
    N=$(($N+1))
done
