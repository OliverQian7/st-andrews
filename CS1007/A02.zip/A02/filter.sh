#!/bin/bash

#checks if user has entered one argument and throws error if they have not
if [ $# -ne 1 ]; then
  echo "Usage: $0 <dir>" >&2
  exit 1
fi

#checks if entered directory exists and throws error message if it doesn't
if [ ! -d $1 ]; then
    echo "Error: directory doesn't exist"
    exit 1
fi

#checks if data directory exists and throws error message if it doesn't
if [ ! -d $1/data ]; then
    echo "Error: data directory doesn't exist"
    exit 1
fi

#sorts files in data by size and lists the top 5 largest files
ls -S $1/data | head -n5

