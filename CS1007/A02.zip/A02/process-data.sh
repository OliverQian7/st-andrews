#!/bin/bash
UseT="false"
#handles -t flag
while getopts "t:" arg; do
    case $arg in
	t)
	    #check if entered directory exits
	    if [ ! -d $OPTARG ]; then
		echo "error: directory $OPTARG does not exist"
		exit 1
	    fi
	    
	    echo "t argument: $OPTARG" >> $OPTARG/log.txt
	    
	    #creates new directory and poopulates it with the largest 5 files in data 
	    if [ -d $OPTARG/top5 ]; then
		rm -rf $OPTARG/top5/*
	    else
		mkdir $OPTARG/top5
	    fi
	    
	    for f in `bash filter.sh $OPTARG`; do
		cp "$OPTARG/data/$f" $OPTARG/top5;
	    done
	    
	    cd $OPTARG
	    DIRECTORY="top5"
	    UseT="true"
	    ;;
	*)
	    echo "error: invalid flag"
	    exit 1
	    ;;
    esac
done

#checks if the user entered in a valid number of arguments and throws error if they did not
if [[ $# -lt 1 ]] || [[ $# -gt 2 ]]; then
    echo "error: usage $0 [OPTION] <dir>"
    exit 1
fi

#handles directory use depending on if -t is used or not
if [[ "$UseT" == "true" ]]; then
    echo "t used" >> log.txt
else

    #checks if entered directory exists
    if [ ! -d $1 ]; then
	echo "error: directory $1 does not exist"
	exit 1
    fi
    
    cd $1
    DIRECTORY="data"
    echo "t not used" >> log.txt
fi

echo "route,duration" > out/duration.csv    #creates duration.csv
IFS=$'\n'    #make newlines the delimiter for for loops

#populate duration.csv with correct data
for f in $(ls $DIRECTORY); do
    TIME=`awk -F "," 'BEGIN { TOTAL=0 }NR>1{ DELTA=$(NF-2)-$1; TOTAL+=DELTA } END {AVG=TOTAL/(NR-1); print AVG}' $DIRECTORY/$f` ; #find average duration of each route in seconds
    DURATION=`date -d@$TIME -u +%H:%M:%S` ; ROUTE=`echo $f | sed 's/\.csv$//'`; #convert seconds into Hours:Minutes:Seconds format
    echo $ROUTE,$DURATION >> out/duration.csv; #prints route and average duration into duration.csv
done    

echo "id,fuel" > out/engine.csv #creates engine.csv
touch trips.csv #creates trips.csv

##populates trip.csv file with all trips
for f in $(ls $DIRECTORY); do
    awk -F "," 'NR>1 { print $(NF-1)","$NF }' $DIRECTORY/$f >> trips.csv ;
done

awk -F "," ' {print $1","$2} ' trips.csv | sort > sorttrips.csv #sorts the trips by vehicle ID and populates a new csv file

#use awk script to calculate total amount of feul used for each vehicle id and writes them to engine.csv
awk ' BEGIN { TOTAL=0; PREV=$1 ; FS="," } { if ( PREV!=$1 ) { print PREV","TOTAL ; PREV=$1 ; TOTAL=$2 } else { TOTAL+=$2 ; PREV=$1 }  } END { print PREV","TOTAL } ' sorttrips.csv >> out/engine.csv

#format engine correctly
sed '2d' out/engine.csv > engine1.csv
cat engine1.csv > out/engine.csv

#removes the engine1.csv, trips.csv and sorttrips.csv files
rm trips.csv
rm sorttrips.csv
rm engine1.csv

exit 0
