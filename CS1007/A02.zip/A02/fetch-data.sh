#!usr/bin/bash
#checks if user entered in 2 arguments and throws error if they did not
if [ $# -ne 2 ]; then
    echo "error: usage $0 <directory name> <base URL>" > stderr
    exit 1
fi
#creates directory if it doesn't exist
if [ ! -d $1 ]; then
    mkdir "$1"
fi
cd $1
touch log.txt
#removes files from data and out directories if they exist and creates them if they do not
if [ -d data ]; then
    rm -rf data/*
else
    mkdir data
fi
if [ -d out ]; then
    rm -rf out/*
else
    mkdir out
fi
#downloads filelist.txt
wget $2/filelist.txt
#replaces space characters with %20 and puts them in new text file
sed 's/ /%20/g' filelist.txt > filelis.txt
COUNT=1
#find the number of files in filelist.txt
NUMLINES=`wc -l < filelis.txt`
echo "number of lines is $NUMLINES" >> log.txt
#dowload files listed in filelist
while [[ $COUNT -le $NUMLINES ]]; do
    #gets specific line from filelis.txt
    DOWNLOAD=`head -n $COUNT filelis.txt | tail -n 1`
    echo "File $COUNT: $DOWNLOAD" >> log.txt
    wget $2/$DOWNLOAD -P data
    COUNT=$(($COUNT + 1))
done
#removal of filelist.txt and filelis.txt
rm filelist.txt
rm filelis.txt
exit 0
