public class SquareMug extends CuboidMug {
    public SquareMug(String name, int size) {
        super(name, size, size, size);
    }    
}
