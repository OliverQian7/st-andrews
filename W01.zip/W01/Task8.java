import java.util.*;
public class Task8 {
    public static void main(String[] args) {
        Set<Book> books = new HashSet<>();
        Book book1 = new Book("The Catcher in the Rye", "J.D. Salinger");
        Book book2 = new Book("Grapes of Wrath", "George Steinbeck");
        Book book3 = new Book("Green Eggs and Ham", "Doctor Suess");
        books.add(book1);
        books.add(book2);
        books.add(book3);
        System.out.println(book1.hashCode());
        System.out.println(book2.hashCode());
        for (Book book:books) {
            System.out.println(book.equals(book1));
        }
    }
}
