import java.util.*;
public class Task7 {
    public static void main(String[] args) {
        Map<String, Country> countries = new HashMap<>();
        Country usa = new Country("USA", "Washington DC", 325000000);
        Country spain = new Country("Spain", "Madrid", 47420000);
        Country france = new Country("France", "Paris", 67750000);
        Country japan = new Country("Japan", "Tokoyo", 125700000);
        countries.put("USA", usa);
        countries.put("Spain", spain);
        countries.put("France", france);
        countries.put("Japan", japan);

            for (String country : countries.keySet()) {
                System.out.println("Country: " + countries.get(country).name + " Capital: " + countries.get(country).capital + " Population: " + countries.get(country).population);
            }
    }
}
