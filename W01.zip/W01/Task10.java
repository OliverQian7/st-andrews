import java.util.*;
public class Task10 {
    public static void main(String[] args) {
        Map<String, Integer> sportsTeamHateIndex = new HashMap<>();
        Map<String, Integer> sportsTeamHateIndex2 = new TreeMap<>();
        sportsTeamHateIndex.put("Celtics", 100);
        sportsTeamHateIndex.put("Arsenal", 95);
        sportsTeamHateIndex.put("Monza", 0);
        sportsTeamHateIndex.put("Patriots", 75);
        sportsTeamHateIndex.put(null, null);
        sportsTeamHateIndex.put("h", null);

        sportsTeamHateIndex2.put("Celtics", 100);
        sportsTeamHateIndex2.put("Arsenal", 95);
        sportsTeamHateIndex2.put("Monza", 0);
        sportsTeamHateIndex2.put("Patriots", 75);
        sportsTeamHateIndex2.put("h", null);
        //sportsTeamHateIndex2.put(null,null);

        System.out.println(sportsTeamHateIndex);
        System.out.println(sportsTeamHateIndex2);
    }
}
