import java.util.*;
public class Task6 {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        Student h = new Student("Henry", 4);
        Student o = new Student("Oscar",97);
        Student b = new Student("Bill", 27);
        students.add(h);
        students.add(o);
        students.add(b);
        System.out.println(students);
        Collections.sort(students);
        System.out.println(students);
        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i).name);
        }
    }
}
