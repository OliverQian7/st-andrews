import java.util.*;
public class Task5 {
    public static void main(String[] args) {
        Map<String, String> countries = new HashMap<>();
        countries.put("USA", "Washington DC");
        countries.put("Spain", "Madrid");
        countries.put("France", "Paris");
        countries.put("Japan", "Tokyo");
        System.out.println(countries.keySet());
        System.out.println(countries.entrySet());
        System.out.println(countries.get("Spain"));
    }
}
