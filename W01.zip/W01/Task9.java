import java.util.*;
public class Task9 {
    public static void main(String[] args) {
        Set<String> colors = new HashSet<>();
        Set<String> treecolors = new TreeSet<>();
        colors.add("Black");
        colors.add("Wine");
        colors.add("Gold");
        colors.add("White");
        treecolors.add("Black");
        treecolors.add("Wine");
        treecolors.add("Gold");
        treecolors.add("White");
        System.out.println(colors);
        System.out.println(treecolors);
        for (String string:colors) {
            System.out.println(string + ": " + string.hashCode());
        }
    }
}
