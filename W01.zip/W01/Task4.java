import java.util.*;
public class Task4 {
    public static void main(String[] args) {
        Set<String> mammals = new HashSet<String>();
        Set<String> oceanlife = new HashSet<String>();
        mammals.add("dolphin");
        mammals.add("elephant");
        mammals.add("hippo");
        mammals.add("whale");
        oceanlife.add("fish");
        oceanlife.add("shark");
        oceanlife.add("dolphin");
        oceanlife.add("whale");
        //mammals.addAll(oceanlife);
        //mammals.retainAll(oceanlife);
        mammals.removeAll(oceanlife);
        System.out.println(mammals);
    }
}
