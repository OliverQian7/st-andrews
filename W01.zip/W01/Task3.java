import java.util.*;
public class Task3 {
    public static void main(String[] args) {
        List<Integer> nums = new ArrayList<Integer>();
        nums.add(1);
        nums.add(2);
        nums.add(99);
        nums.add(7);
        System.out.println(nums);
        Collections.sort(nums);
        System.out.println(nums);
        Collections.reverse(nums);
        System.out.println(nums);
        int sum = 0;
        for (int i = 0; i < nums.size(); i++) {
            sum+=nums.get(i);
        }
        System.out.println(sum);
    }
}
