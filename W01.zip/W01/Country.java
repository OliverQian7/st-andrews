public class Country {
    public String name;
    public String capital;
    public int population;

    public Country(String name, String capital, int population) {
        this.name = name;
        this.capital = capital;
        this.population = population;
    }
}
