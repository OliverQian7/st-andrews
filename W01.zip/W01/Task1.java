import java.util.*;
public class Task1 {
public static void main(String[] args) {
    ArrayList<String> colors = new ArrayList<>();
    colors.add("orange");
    colors.add("red");
    colors.add("green");
    colors.add("blue");
    for (int i = 0; i < colors.size(); i++) {
        System.out.println("Color "+i+": "+colors.get(i));
    }
}
}