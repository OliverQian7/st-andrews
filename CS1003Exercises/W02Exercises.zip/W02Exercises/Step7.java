import java.io.*;
import java.util.*;
public class Step7 {
    public static void main(String[] args) {
        try{
            File input = new File(args[0]);
            File output = new File(args[1]);
            output.mkdir();
            if (input.isDirectory()) {
                for (File file : input.listFiles()) {
                    copy(file, new File(output.getAbsolutePath() + "/" + file.getName()));
                }
            }            
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Put 2 directories as arguments");
        }
    }
    public static void copy(File input, File output) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(input));
            PrintWriter writer = new PrintWriter(output);
            String line = "";
            while ((line = reader.readLine()) != null) {
                writer.println(line);
            }
            reader.close();
            writer.close();
        }
        catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }   
    }
}