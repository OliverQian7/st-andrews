import java.io.*;
import java.util.*;
public class Step4 {
    public static void main(String[] args) {
        try{
            BufferedReader reader = new BufferedReader(new FileReader(args[0]));
            String line = "";
            int lines = 0;
            Map<String,Fruit> fruits = new HashMap<>();

            while ((line = reader.readLine()) != null) {
                String[] split = line.split("\t");
                fruits.put(line.split("\t")[0], new Fruit(split[0],split[1], Integer.parseInt(split[2]), Double.parseDouble(split[3])));
            }
            //System.out.println(lines);
            System.out.println(fruits);
            reader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
        catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Put file as an argument");
        }
    }

}