public class Fruit {
    public String name;
    public String country;
    public int number;
    public double cost;

    public Fruit(String name, String conutry, int number, double cost) {
        this.name = name;
        this.country = country;
        this.number = number;
        this.cost = cost;
    }
}
