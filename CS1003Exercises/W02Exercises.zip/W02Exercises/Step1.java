import java.io.*;
public class Step1 {
    public static void main(String[] args) {
        try{
            BufferedReader reader = new BufferedReader(new FileReader("test-short.txt"));
            int lines = 0;
            while (reader.readLine() != null) {
                lines++;
            }
            System.out.println(lines);
            reader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
        catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }
    }

}