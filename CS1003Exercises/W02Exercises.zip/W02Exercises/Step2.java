import java.io.*;
public class Step2 {
    public static void main(String[] args) {
        try{
            BufferedReader reader = new BufferedReader(new FileReader("test-short.txt"));
            String line = "";
            int words = 0;
            while ((line = reader.readLine()) != null) {
                if (line.length() == 0) continue;
                words += line.split(" ").length;
            }
            System.out.println(words);
            reader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
        catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }
    }

}