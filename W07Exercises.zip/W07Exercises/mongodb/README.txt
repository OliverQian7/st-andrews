Usage:

In order to run the MongoDB server, in the CS Labs on Linux, or if
you have Mercurial installed:

   hg clone https://sysc-public.hg.cs.st-andrews.ac.uk/mongodb
   cd mongodb
   ./mongodb

The script outputs the MongoDB admin username, admin password, MongoDB
URI, and database path when run. On the first run it will install the
container, same will be re-used on subsequent runs.

The following instructions are for people not using the CS Labs, or
people using their own computers (with a Unix environment and Podman).

If not in the CS Labs, or if using your own machine (with Unix tools):

   curl -O https://sysc-public.hg.cs.st-andrews.ac.uk/mongodb/archive/tip.tar.gz
   tar zxvf tip.tar.gz
   cd mongodb-*
   ./mongodb

The script outputs the MongoDB admin username, admin password, MongoDB
URI, and database path when run. On the first run it will install the
container, same will be re-used on subsequent runs.

NB. The script requires that Podman[1] is installed. You may also want
to install the MongoDB Shell[2]. Both are already installed on CS host
servers and lab clients.

[1]: <https://podman-desktop.io/>
[2]: <https://www.mongodb.com/docs/mongodb-shell/install/>
